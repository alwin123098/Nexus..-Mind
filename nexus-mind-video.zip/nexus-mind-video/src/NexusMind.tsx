import React from "react";
import { AbsoluteFill, Series } from "remotion";
import { SCENE } from "./constants";
import { IntroScene } from "./scenes/IntroScene";
import { TaglineScene } from "./scenes/TaglineScene";
import { CouncilScene } from "./scenes/CouncilScene";
import { SimulationScene } from "./scenes/SimulationScene";
import { FinaleScene } from "./scenes/FinaleScene";

export const NexusMind: React.FC = () => {
  return (
    <AbsoluteFill>
      <Series>
        <Series.Sequence durationInFrames={SCENE.intro.dur}>
          <IntroScene />
        </Series.Sequence>

        <Series.Sequence durationInFrames={SCENE.tagline.dur}>
          <TaglineScene />
        </Series.Sequence>

        <Series.Sequence durationInFrames={SCENE.council.dur}>
          <CouncilScene />
        </Series.Sequence>

        <Series.Sequence durationInFrames={SCENE.simulation.dur}>
          <SimulationScene />
        </Series.Sequence>

        <Series.Sequence durationInFrames={SCENE.finale.dur}>
          <FinaleScene />
        </Series.Sequence>
      </Series>
    </AbsoluteFill>
  );
};
