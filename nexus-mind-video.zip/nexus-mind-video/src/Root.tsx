import React from "react";
import { Composition } from "remotion";
import { NexusMind } from "./NexusMind";
import { FPS, WIDTH, HEIGHT, DURATION_FRAMES } from "./constants";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="NexusMind"
      component={NexusMind}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  </>
);
