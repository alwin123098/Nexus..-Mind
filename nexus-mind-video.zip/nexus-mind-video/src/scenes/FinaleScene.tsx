import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C } from "../constants";

const MODELS = ["GLM-5", "Qwen3.5-235B", "DeepSeek V3.2", "Kimi K2.5"];

export const FinaleScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const logoSpring = spring({ fps, frame, config: { damping: 160, stiffness: 80 } });
  const logoOpacity = interpolate(frame, [0, 25], [0, 1], { extrapolateRight: "clamp" });

  const lineW = interpolate(frame, [20, 55], [0, 480], { extrapolateRight: "clamp" });

  const tagOpacity = interpolate(frame, [40, 65], [0, 1], { extrapolateRight: "clamp" });
  const tagY = interpolate(frame, [40, 65], [30, 0], { extrapolateRight: "clamp" });

  const powOpacity = interpolate(frame, [70, 90], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: C.bg, alignItems: "center", justifyContent: "center" }}>
      {/* Background glow */}
      <div style={{
        position: "absolute",
        width: 1000, height: 700,
        borderRadius: "50%",
        background: `radial-gradient(ellipse, ${C.accent} 0%, transparent 65%)`,
        opacity: 0.07 * logoOpacity,
        top: "50%", left: "50%",
        transform: "translate(-50%, -50%)",
      }} />

      {/* Cinematic bars */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 80, background: "#000" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 80, background: "#000" }} />

      <div style={{ textAlign: "center", zIndex: 1 }}>
        {/* Logo */}
        <div style={{
          opacity: logoOpacity,
          transform: `scale(${0.85 + 0.15 * logoSpring})`,
          fontSize: 140,
          fontWeight: 800,
          color: C.text,
          fontFamily: "'Courier New', monospace",
          letterSpacing: "0.18em",
          marginBottom: 20,
        }}>
          NEXUS MIND
        </div>

        {/* Accent line */}
        <div style={{
          height: 3,
          width: lineW,
          margin: "0 auto 48px",
          background: C.accent,
          opacity: 0.85,
        }} />

        {/* Tagline */}
        <div style={{
          opacity: tagOpacity,
          transform: `translateY(${tagY}px)`,
          fontSize: 64,
          fontWeight: 300,
          color: C.text,
          letterSpacing: "0.05em",
          marginBottom: 60,
        }}>
          Your decisions. Amplified.
        </div>

        {/* Powered by */}
        <div style={{
          opacity: powOpacity,
          fontSize: 22,
          color: C.sub,
          letterSpacing: "0.28em",
          fontFamily: "'Courier New', monospace",
          marginBottom: 28,
        }}>
          POWERED BY OPEN INTELLIGENCE
        </div>

        {/* Model tags */}
        <div style={{
          opacity: powOpacity,
          display: "flex",
          justifyContent: "center",
          gap: 20,
          flexWrap: "wrap",
        }}>
          {MODELS.map((m, i) => (
            <div key={i} style={{
              fontSize: 22,
              color: C.accent,
              border: `1px solid ${C.accent}50`,
              padding: "8px 22px",
              borderRadius: 8,
              fontFamily: "'Courier New', monospace",
              letterSpacing: "0.08em",
            }}>
              {m}
            </div>
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
