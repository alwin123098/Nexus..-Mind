import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, PERSONAS } from "../constants";

const PersonaCard: React.FC<{
  persona: typeof PERSONAS[number];
  delay: number;
}> = ({ persona, delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cardSpring = spring({ fps, frame: frame - delay, config: { damping: 140, stiffness: 90 } });
  const opacity = interpolate(frame, [delay, delay + 15], [0, 1], { extrapolateRight: "clamp" });

  return (
    <div style={{
      opacity,
      transform: `scale(${0.7 + 0.3 * cardSpring}) translateY(${(1 - cardSpring) * 40}px)`,
      background: "rgba(255,255,255,0.025)",
      border: `1.5px solid ${persona.color}55`,
      borderRadius: 16,
      padding: "48px 36px",
      textAlign: "center",
      width: 380,
    }}>
      <div style={{ fontSize: 72, color: persona.color, marginBottom: 20, lineHeight: 1 }}>
        {persona.glyph}
      </div>
      <div style={{
        fontSize: 32,
        fontWeight: 700,
        color: persona.color,
        letterSpacing: "0.15em",
        fontFamily: "'Courier New', monospace",
        marginBottom: 12,
      }}>
        {persona.name}
      </div>
      <div style={{ fontSize: 24, color: C.sub }}>
        {persona.role}
      </div>
    </div>
  );
};

export const CouncilScene: React.FC = () => {
  const frame = useCurrentFrame();
  const headerOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });
  const tagOpacity = interpolate(frame, [120, 145], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: C.bg, alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 60 }}>
      {/* Cinematic bars */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 80, background: "#000" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 80, background: "#000" }} />

      {/* Header */}
      <div style={{
        opacity: headerOpacity,
        fontSize: 28,
        letterSpacing: "0.35em",
        color: C.sub,
        fontFamily: "'Courier New', monospace",
        zIndex: 1,
      }}>
        THE COUNCIL
      </div>

      {/* Cards grid */}
      <div style={{
        display: "flex",
        gap: 32,
        zIndex: 1,
        flexWrap: "wrap",
        justifyContent: "center",
        padding: "0 80px",
      }}>
        {PERSONAS.map((p, i) => (
          <PersonaCard key={p.name} persona={p} delay={15 + i * 22} />
        ))}
      </div>

      {/* Bottom tag */}
      <div style={{
        opacity: tagOpacity,
        fontSize: 26,
        letterSpacing: "0.28em",
        color: C.sub,
        fontFamily: "'Courier New', monospace",
        zIndex: 1,
      }}>
        FOUR MINDS · ONE DECISION
      </div>
    </AbsoluteFill>
  );
};
