import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C } from "../constants";

export const IntroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Title fade + slide up
  const titleOpacity = interpolate(frame, [0, 25], [0, 1], { extrapolateRight: "clamp" });
  const titleY = interpolate(frame, [0, 30], [60, 0], { extrapolateRight: "clamp" });

  // Underline draws from left
  const lineScale = spring({ fps, frame: frame - 20, config: { damping: 120, stiffness: 80 } });

  // Version tag
  const versionOpacity = interpolate(frame, [45, 65], [0, 1], { extrapolateRight: "clamp" });

  // Subtle glow pulse
  const glowOpacity = interpolate(frame, [0, 45, 90], [0, 0.12, 0.08], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: C.bg, alignItems: "center", justifyContent: "center" }}>
      {/* Background glow */}
      <div style={{
        position: "absolute",
        width: 900, height: 600,
        borderRadius: "50%",
        background: `radial-gradient(ellipse, ${C.accent} 0%, transparent 65%)`,
        opacity: glowOpacity,
        top: "50%", left: "50%",
        transform: "translate(-50%, -50%)",
      }} />

      {/* Cinematic bars */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 80, background: "#000" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 80, background: "#000" }} />

      {/* Content */}
      <div style={{ textAlign: "center", zIndex: 1 }}>
        <div style={{
          opacity: titleOpacity,
          transform: `translateY(${titleY}px)`,
          fontSize: 140,
          fontWeight: 800,
          color: C.text,
          fontFamily: "'Courier New', monospace",
          letterSpacing: "0.18em",
          marginBottom: 24,
        }}>
          NEXUS MIND
        </div>

        {/* Accent underline */}
        <div style={{
          height: 3,
          width: 500,
          margin: "0 auto 28px",
          background: C.accent,
          transformOrigin: "left",
          transform: `scaleX(${lineScale})`,
          opacity: 0.9,
        }} />

        {/* Version */}
        <div style={{
          opacity: versionOpacity,
          fontSize: 28,
          color: C.sub,
          letterSpacing: "0.45em",
          fontFamily: "'Courier New', monospace",
        }}>
          V E R S I O N &nbsp;&nbsp; 2 . 0
        </div>
      </div>
    </AbsoluteFill>
  );
};
