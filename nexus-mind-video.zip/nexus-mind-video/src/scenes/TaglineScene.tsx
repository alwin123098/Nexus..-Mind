import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { C } from "../constants";

const words = ["The", "AI", "that", "thinks", "before", "you", "decide."];

export const TaglineScene: React.FC = () => {
  const frame = useCurrentFrame();

  const subOpacity = interpolate(frame, [65, 85], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: C.bg, alignItems: "center", justifyContent: "center" }}>
      {/* Cinematic bars */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 80, background: "#000" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 80, background: "#000" }} />

      <div style={{ textAlign: "center", zIndex: 1, padding: "0 120px" }}>
        {/* Word-by-word reveal */}
        <div style={{
          fontSize: 96,
          fontWeight: 600,
          color: C.text,
          lineHeight: 1.4,
          letterSpacing: "0.02em",
          marginBottom: 60,
        }}>
          {words.map((word, i) => {
            const start = i * 8;
            const opacity = interpolate(frame, [start, start + 12], [0, 1], { extrapolateRight: "clamp" });
            const y = interpolate(frame, [start, start + 12], [30, 0], { extrapolateRight: "clamp" });
            return (
              <span
                key={i}
                style={{
                  opacity,
                  display: "inline-block",
                  marginRight: "0.3em",
                  transform: `translateY(${y}px)`,
                }}
              >
                {word}
              </span>
            );
          })}
        </div>

        {/* Subtitle */}
        <div style={{
          opacity: subOpacity,
          fontSize: 28,
          color: C.accent,
          letterSpacing: "0.32em",
          fontFamily: "'Courier New', monospace",
        }}>
          MULTI-AGENT · OPEN-SOURCE · ZERO CLOUD
        </div>
      </div>
    </AbsoluteFill>
  );
};
