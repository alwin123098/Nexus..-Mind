import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { C } from "../constants";

const BAR_HEIGHTS = [0.42, 0.66, 0.5, 0.87, 0.44, 0.76, 0.61, 0.95, 0.7, 0.89, 0.55, 0.79, 0.48, 0.72, 0.83, 0.6];

export const SimulationScene: React.FC = () => {
  const frame = useCurrentFrame();

  const headerOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });
  const titleOpacity = interpolate(frame, [10, 35], [0, 1], { extrapolateRight: "clamp" });
  const titleY = interpolate(frame, [10, 35], [40, 0], { extrapolateRight: "clamp" });
  const legendOpacity = interpolate(frame, [80, 105], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: C.bg, alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
      {/* Cinematic bars */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 80, background: "#000" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 80, background: "#000" }} />

      <div style={{ width: 1400, zIndex: 1 }}>
        {/* Label */}
        <div style={{
          opacity: headerOpacity,
          fontSize: 26,
          letterSpacing: "0.35em",
          color: C.accent,
          fontFamily: "'Courier New', monospace",
          marginBottom: 20,
          textAlign: "center",
        }}>
          FUTURE SIMULATION ENGINE
        </div>

        {/* Title */}
        <div style={{
          opacity: titleOpacity,
          transform: `translateY(${titleY}px)`,
          fontSize: 88,
          fontWeight: 700,
          color: C.text,
          marginBottom: 80,
          textAlign: "center",
          letterSpacing: "0.03em",
        }}>
          Simulate. Predict. Decide.
        </div>

        {/* Bar chart */}
        <div style={{ display: "flex", alignItems: "flex-end", gap: 16, height: 260, marginBottom: 0 }}>
          {BAR_HEIGHTS.map((h, i) => {
            const barStart = 25 + i * 4;
            const barProgress = interpolate(frame, [barStart, barStart + 20], [0, 1], { extrapolateRight: "clamp" });
            const isHighlight = h > 0.74;
            return (
              <div
                key={i}
                style={{
                  flex: 1,
                  height: `${barProgress * h * 100}%`,
                  background: isHighlight ? C.accent : `${C.accent}3A`,
                  borderRadius: "4px 4px 0 0",
                }}
              />
            );
          })}
        </div>

        {/* Axis line */}
        <div style={{ height: 2, background: `${C.accent}30`, marginBottom: 28 }} />

        {/* Legend */}
        <div style={{
          opacity: legendOpacity,
          display: "flex",
          gap: 48,
          justifyContent: "center",
          fontSize: 22,
          color: C.sub,
          fontFamily: "'Courier New', monospace",
          letterSpacing: "0.15em",
        }}>
          {["SCENARIO A", "SCENARIO B", "OPTIMAL PATH"].map((label, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{
                width: 18, height: 18, borderRadius: 3,
                background: i === 2 ? C.accent : `${C.accent}3A`,
              }} />
              {label}
            </div>
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
