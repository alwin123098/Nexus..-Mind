export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const DURATION_FRAMES = 22 * FPS; // 22 seconds = 660 frames

export const C = {
  bg: "#03030D",
  text: "#EEEEFF",
  sub: "#4A4A72",
  accent: "#4A7EE8",
  oracle: "#4A7EE8",
  strat: "#CC8B18",
  devil: "#CC4444",
  guard: "#22A8A3",
};

export const PERSONAS = [
  { name: "ORACLE",      role: "Pattern Recognition",  color: C.oracle, glyph: "◎" },
  { name: "STRATEGIST",  role: "Long-term Planning",   color: C.strat,  glyph: "◆" },
  { name: "ADVOCATE",   role: "Risk Analysis",         color: C.devil,  glyph: "▲" },
  { name: "GUARDIAN",   role: "Truth Filtering",       color: C.guard,  glyph: "◉" },
];

// Scene start frames
export const SCENE = {
  intro:      { from: 0,   dur: 90  }, // 0–3s
  tagline:    { from: 90,  dur: 90  }, // 3–6s
  council:    { from: 180, dur: 180 }, // 6–12s
  simulation: { from: 360, dur: 120 }, // 12–16s
  finale:     { from: 480, dur: 180 }, // 16–22s
};
