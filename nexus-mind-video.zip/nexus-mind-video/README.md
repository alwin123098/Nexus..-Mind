# NEXUS MIND — Cinematic Demo Video

Dark cinematic 22-second product demo built with Remotion.

## Setup (needs a PC with Node.js installed)

```bash
# 1. Install dependencies
npm install

# 2. Preview in Remotion Studio (localhost:3000)
npm run dev

# 3. Render to MP4
npm run build
# Output: out/nexus-mind.mp4
```

## Video Details
- Resolution: 1920×1080 (Full HD)
- FPS: 30
- Duration: 22 seconds
- Style: Dark cinematic

## Scenes
| Scene      | Time    | Content                        |
|------------|---------|--------------------------------|
| Intro      | 0–3s    | NEXUS MIND logo reveal         |
| Tagline    | 3–6s    | Word-by-word tagline animation |
| Council    | 6–12s   | 4 persona cards reveal         |
| Simulation | 12–16s  | Future simulation bar chart    |
| Finale     | 16–22s  | Brand close + model tags       |

## Customise
- Colors → `src/constants.ts` (C object)
- Add audio → drop MP3 in `public/` and add `<Audio>` in `NexusMind.tsx`
- Change text → edit individual scene files in `src/scenes/`
